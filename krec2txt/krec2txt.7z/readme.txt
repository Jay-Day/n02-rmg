------------------------
 -- krec2text --
------------------------

Converts Kaillera game record (.krec) files into text format

useage:  krec2txt [/b] [input file name]

the /b clause is optional and causes data to be in binary instead of hex

it will output on console so use the ">" to redirect output to file

e.g. The following commands were used to generate the text files in the samples directory:

krec2txt "samples\Fatal_Fury_Special[1189294234].krec" > "samples\Fatal_Fury_Special[1189294234].krec.txt"
krec2txt /b "samples\Fatal_Fury_Special[1189294234].krec" > "samples\Fatal_Fury_Special[1189294234].krec.b.txt"

#include <stdio.h>
#include "windows.h"

HFILE in;
int VERSION = *((int*)"KRC0");
char * buffer = 0;
char * ptr;
char * end;
bool in_load_file(char * fn) {
	in = _lopen(fn, OF_READ);
	if (in != HFILE_ERROR) {
		DWORD  buffer_size;
		buffer_size = GetFileSize((HANDLE)in, 0);
		if (buffer_size > 256) {
			buffer = (char*)malloc(buffer_size+10);
			memset(buffer+buffer_size, 0, 10);
			_lread(in, buffer, buffer_size);
			ptr = buffer;
			end = ptr + buffer_size;
			_lclose(in);
			return true;
		} else {
			printf("File too small\r\n");
			_lclose(in);
		}
	} else {
		printf("Error opening file: %s\r\n", fn);
	}
	return false;
}

void buffer_seek(int n) {
	ptr = buffer + n;	
}
void buffer_load_bytes(void * b, int l) {
	char * bb = (char*)b;
	for (int x = 0; x < l; x++){
		*bb++ = *ptr++;
	}
}
int buffer_load_int() {
	int r;
	buffer_load_bytes(&r, 4);
	return r;
}
int buffer_load_short() {
	short r;
	buffer_load_bytes(&r, 2);
	return r;
}
int buffer_load_char() {
	char r;
	buffer_load_bytes(&r, 1);
	return r;
}
void buffer_load_string(char * b) {
	int bb = strlen(ptr)+1;
	buffer_load_bytes(b, bb);
}

bool in_unload() {
	if (buffer!=0){
		free(buffer);
		buffer = 0;
	}
	return true;
}

/*========================================
// Recorder file format, VERSION == *"KRC0"
//----------------------------------------
        Offfset | Field name/description
		+-------+--------------------------+
		| 0x000 | VERSION                  |
		+-------+--------------------------+
		| 0x004 | Emulator Name            |
		+-------+--------------------------+
		| 0x084 | Game Name                |
		+-------+--------------------------+
		| 0x104 | c timestamp              |
		+-------+--------------------------+
		| 0x108 | player no                |
		+-------+--------------------------+
		| 0x10c | Total players            |
		+-------+--------------------------+
		| 0x110 | game data                |
		+-------+--------------------------+
Game data format:
	frame data: byte 0x12 followed by 2 bytes length followed by that many bytes od fata
	chat  data: byte 0x08 followed by null terminated username and null terminated chat message
	drop  data: byte 0x14 followed by null terminated username and 4 bytes player no
//======================================*/

void BINOUT(unsigned char xx){
	unsigned char HIB = (xx & 0xF0)>>4;
	unsigned char LOB = (xx & 0x0F)>>0;
	char * binstrs[] = {"0000","0001","0010","0011","0100","0101","0110","0111", "1000","1001","1010","1011","1100","1101","1110","1111"};
	printf("%s%s", binstrs[HIB], binstrs[LOB]);
}
void HEXOUT(unsigned char xx){
	printf("%02X", xx);
}
void (*OUTP)(unsigned char);
int main(int argc, char * args[]) {
	bool BINOUTP = false;
	if (argc > 1) {
		char * INPFILE = 0;
		for (int ax = 1; ax < argc; ax++){
			if (strncmp(args[ax],"/b", 2)==0) {
				BINOUTP = true;
			} else {
				INPFILE = args[ax];
			}
		}
		
		if (INPFILE == 0 || strlen(INPFILE)==0) {
			printf("Input file not specified");
			return 1;
		} else {
			printf("Input: %s\r\n",INPFILE);
		}
		
		if (BINOUTP)
			OUTP = BINOUT;
		else
			OUTP = HEXOUT;		
		if (in_load_file(INPFILE)) {
			printf("File: %s loaded successfully\r\n", INPFILE);
			if (buffer_load_int() == VERSION) {
				char emu[256];
				buffer_load_string(emu);
				printf("Emu: %s\r\n", emu);
				
				buffer_seek(132);
				char game[256];
				buffer_load_string(game);
				printf("Game: %s\r\n", game);
				
				buffer_seek(260);
				int time;
				time = buffer_load_int();
				printf("Time: %i\r\n", time);
				
				int pno;
				int nps;
				pno = buffer_load_int();
				nps = buffer_load_int();
				printf("Player: %i/%i\r\n", pno,nps);
				
				char code;
				unsigned char buff[256];
				short buffl;
				int frame = 0;
				
				while (ptr < end) {
					code = buffer_load_char();
					switch(code) {
					case 0x12:
						buffl = buffer_load_short();
						if (buffl > 0) {
							buffer_load_bytes(buff, buffl);
						}
						printf("Frame: no=%i, size=%i, data=", frame++, buffl);
						for(int x = 0; x < buffl; x++)
							OUTP(buff[x]);
						
						printf("\r\n");
						break;
					case 0x08:
						{
							char username[128];
							char chatmesg[256];
							buffer_load_string(username);
							buffer_load_string(chatmesg);
							printf("Chat: <%s> %s\r\n", username, chatmesg);
							break;
						}
					case 0x14:
						{
							char username[128];
							buffer_load_string(username);
							int playern = buffer_load_int();
							printf("PDrop: %s (player %i)\r\n", username, playern);
							break;
						}
					default:
						printf("unknown code = %i", code);
						ptr = end;
						break;
					};
				}				
			} else {
				printf("File format unrecognized\r\n");
			}
			in_unload();
		}
	} else {
		printf("not enough arguments specified", argc);
	}
	return 0;
}
